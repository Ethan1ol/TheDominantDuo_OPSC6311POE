package com.example.tester.Activity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tester.R

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val name = findViewById<EditText>(R.id.editName)
        val surname = findViewById<EditText>(R.id.editSurname)
        val username = findViewById<EditText>(R.id.editUsername)
        val email = findViewById<EditText>(R.id.editEmail)
        val password = findViewById<EditText>(R.id.editPassword)
        val phone = findViewById<EditText>(R.id.editPhoneNumber)

        val submit = findViewById<Button>(R.id.button2)

        submit.setOnClickListener {

            val nameText = name.text.toString().trim()
            val surnameText = surname.text.toString().trim()
            val usernameText = username.text.toString().trim()
            val emailText = email.text.toString().trim()
            val passwordText = password.text.toString().trim()
            val phoneText = phone.text.toString().trim()

            var valid = true

            //Checks Name
            if (nameText.isEmpty()) {
                name.error = "Name required"
                valid = false
            }

            // Checks Surname
            if (surnameText.isEmpty()) {
                surname.error = "Surname required"
                valid = false
            }

            // Checks Username
            if (usernameText.length < 4) {
                username.error = "Username too short"
                valid = false
            }

            // Checks Email
            if (!emailText.contains("@")) {
                email.error = "Invalid email"
                valid = false
            }

            // Checks the riles of password
            if (passwordText.length < 5 ||
                !passwordText.any { it.isUpperCase() } ||
                !passwordText.any { it.isDigit() }
            ) {
                password.error = "Weak password"
                valid = false
            }

            // Checks for entered phone number
            if (phoneText.length < 10 && !phoneText.all { it.isDigit() }) {
                phone.error = "Invalid phone number"
                valid = false
            }

            //Shows if registration is or is not
            if (valid) {
                Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, HomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)

            } else {
                Toast.makeText(this, "Please fix errors", Toast.LENGTH_SHORT).show()
            }
        }
    }
}