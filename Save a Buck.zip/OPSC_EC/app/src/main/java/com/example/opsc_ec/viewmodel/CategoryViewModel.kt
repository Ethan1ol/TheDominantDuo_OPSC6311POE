package com.example.opsc_ec.viewmodel

import androidx.lifecycle.*
import com.example.opsc_ec.database.Category
import com.example.opsc_ec.database.CategoryWithTotal
import com.example.opsc_ec.database.Expense
import com.example.opsc_ec.database.BudgetRepository
import kotlinx.coroutines.launch

class CategoryViewModel(private val repository: BudgetRepository) : ViewModel() {

    fun getCategories(userId: Int): LiveData<List<CategoryWithTotal>> {
        return repository.getCategoriesWithTotals(userId).asLiveData()
    }

    fun getCategoriesForPeriod(userId: Int, rangeStart: Long, rangeEnd: Long): LiveData<List<CategoryWithTotal>> {
        return repository.getCategoriesWithTotalsForPeriod(userId, rangeStart, rangeEnd).asLiveData()
    }

    fun addCategory(name: String, userId: Int) {
        viewModelScope.launch {
            val newCategory = Category(name = name, userId = userId)
            repository.insertCategory(newCategory)
        }
    }

    fun getExpensesForCategory(categoryId: Int): LiveData<List<Expense>> {
        return repository.getExpensesForCategory(categoryId).asLiveData()
    }

    fun getExpensesForCategoryAndPeriod(categoryId: Int, rangeStart: Long, rangeEnd: Long): LiveData<List<Expense>> {
        return repository.getExpensesForCategoryAndPeriod(categoryId, rangeStart, rangeEnd).asLiveData()
    }
}

class CategoryViewModelFactory(private val repository: BudgetRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CategoryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CategoryViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
