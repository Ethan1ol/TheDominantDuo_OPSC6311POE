package com.example.opsc_ec.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.navigation.fragment.findNavController
import com.example.opsc_ec.R
import com.example.opsc_ec.database.AppDatabase
import com.example.opsc_ec.database.BudgetRepository
import com.example.opsc_ec.databinding.FragmentCategoryBinding
import com.example.opsc_ec.viewmodel.CategoryViewModel
import com.example.opsc_ec.viewmodel.CategoryViewModelFactory
import java.util.*

class CategoryFragment : Fragment() {

    private var _binding: FragmentCategoryBinding? = null
    private val binding get() = _binding!!

    // User ID passed from Login
    private var currentUserId: Int = 1 

    private val viewModel: CategoryViewModel by viewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val repository = BudgetRepository(database.appDao())
        CategoryViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            currentUserId = it.getInt("userId", 1)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCategoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = CategoryAdapter { category ->
            val bundle = Bundle().apply {
                putInt("categoryId", category.id)
                putString("categoryName", category.name)
                putInt("userId", currentUserId)
            }
            findNavController().navigate(R.id.action_CategoryFragment_to_CategoryDetailsFragment, bundle)
        }
        binding.rvCategories.apply {
            this.adapter = adapter
            layoutManager = LinearLayoutManager(requireContext())
        }

        setupMonthSpinner(adapter)

        binding.btnAddCategory.setOnClickListener {
            showAddCategoryDialog()
        }
    }

    private fun setupMonthSpinner(adapter: CategoryAdapter) {
        val months = arrayOf("All", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, months)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerMonthCategory.adapter = spinnerAdapter

        binding.spinnerMonthCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    // Show all time totals
                    viewModel.getCategories(currentUserId).observe(viewLifecycleOwner) { categories ->
                        adapter.submitList(categories)
                    }
                } else {
                    // Filter by month
                    val calendar = Calendar.getInstance()
                    calendar.set(Calendar.MONTH, position - 1)
                    calendar.set(Calendar.DAY_OF_MONTH, 1)
                    calendar.set(Calendar.HOUR_OF_DAY, 0)
                    calendar.set(Calendar.MINUTE, 0)
                    calendar.set(Calendar.SECOND, 0)
                    calendar.set(Calendar.MILLISECOND, 0)
                    val rangeStart = calendar.timeInMillis

                    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
                    calendar.set(Calendar.HOUR_OF_DAY, 23)
                    calendar.set(Calendar.MINUTE, 59)
                    calendar.set(Calendar.SECOND, 59)
                    calendar.set(Calendar.MILLISECOND, 999)
                    val rangeEnd = calendar.timeInMillis

                    viewModel.getCategoriesForPeriod(currentUserId, rangeStart, rangeEnd).observe(viewLifecycleOwner) { categories ->
                        adapter.submitList(categories)
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun showAddCategoryDialog() {
        val builder = android.app.AlertDialog.Builder(requireContext())
        builder.setTitle("Add New Category")
        
        val input = android.widget.EditText(requireContext())
        input.hint = "Category Name"
        builder.setView(input)

        builder.setPositiveButton("Add") { dialog, _ ->
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                viewModel.addCategory(name, currentUserId)
                Toast.makeText(requireContext(), "Category added", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }

        builder.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
