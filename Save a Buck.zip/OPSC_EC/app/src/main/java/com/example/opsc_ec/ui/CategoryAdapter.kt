package com.example.opsc_ec.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.opsc_ec.database.CategoryWithTotal
import com.example.opsc_ec.databinding.ItemCategoryBinding
import java.util.Locale

class CategoryAdapter(private val onCategoryClick: (CategoryWithTotal) -> Unit) : 
    ListAdapter<CategoryWithTotal, CategoryAdapter.CategoryViewHolder>(CategoryDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val binding = ItemCategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryViewHolder(binding, onCategoryClick)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class CategoryViewHolder(
        private val binding: ItemCategoryBinding,
        private val onCategoryClick: (CategoryWithTotal) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {
        
        fun bind(category: CategoryWithTotal) {
            binding.tvCategoryName.text = category.name
            val total = category.totalAmount ?: 0.0
            binding.tvTotalAmount.text = String.format(Locale.getDefault(), "R %.2f", total)
            binding.root.setOnClickListener { onCategoryClick(category) }
        }
    }

    class CategoryDiffCallback : DiffUtil.ItemCallback<CategoryWithTotal>() {
        override fun areItemsTheSame(oldItem: CategoryWithTotal, newItem: CategoryWithTotal): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: CategoryWithTotal, newItem: CategoryWithTotal): Boolean {
            return oldItem == newItem
        }
    }
}
