package com.example.opsc_ec.database

data class CategoryGraphs(
    val categoryName: String,
    val totalSpent: Double,
    val minGoal: Double,
    val maxGoal: Double
)