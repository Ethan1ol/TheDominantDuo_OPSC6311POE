package com.example.opsc_ec.viewmodel

import androidx.lifecycle.*
import com.example.opsc_ec.database.User
import com.example.opsc_ec.database.BudgetRepository
import kotlinx.coroutines.launch

class UserViewModel(private val repository: BudgetRepository) : ViewModel() {

    private val _loginResult = MutableLiveData<User?>()
    val loginResult: LiveData<User?> = _loginResult

    private val _registerResult = MutableLiveData<Boolean>()
    val registerResult: LiveData<Boolean> = _registerResult

    fun login(username: String, password: String) {
        viewModelScope.launch {
            val user = repository.getUserByUsername(username)
            if (user != null && user.password == password) {
                _loginResult.postValue(user)
            } else {
                _loginResult.postValue(null)
            }
        }
    }

    fun register(user: User) {
        viewModelScope.launch {
            val existing = repository.getUserByUsername(user.username)
            if (existing == null) {
                repository.insertUser(user)
                _registerResult.postValue(true)
            } else {
                _registerResult.postValue(false)
            }
        }
    }
}

class UserViewModelFactory(private val repository: BudgetRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UserViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return UserViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}