package com.example.opsc_ec.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.opsc_ec.R
import com.example.opsc_ec.database.AppDatabase
import com.example.opsc_ec.database.BudgetRepository
import com.example.opsc_ec.databinding.FragmentCategoryDetailsBinding
import com.example.opsc_ec.viewmodel.CategoryViewModel
import com.example.opsc_ec.viewmodel.CategoryViewModelFactory
import com.example.opsc_ec.viewmodel.ExpenseViewModel
import com.example.opsc_ec.viewmodel.ExpenseViewModelFactory
import java.util.*

class CategoryDetailsFragment : Fragment() {

    private var _binding: FragmentCategoryDetailsBinding? = null
    private val binding get() = _binding!!

    private var categoryId: Int = -1
    private var categoryName: String? = null
    private var userId: Int = 1

    private val viewModel: CategoryViewModel by viewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val repository = BudgetRepository(database.appDao())
        CategoryViewModelFactory(repository)
    }

    private val expenseViewModel: ExpenseViewModel by viewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val repository = BudgetRepository(database.appDao())
        ExpenseViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            categoryId = it.getInt("categoryId", -1)
            categoryName = it.getString("categoryName")
            userId = it.getInt("userId", 1)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCategoryDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvCategoryNameDetail.text = categoryName ?: "Unknown"

        val adapter = ExpenseAdapter { expense ->
            showUpdateSpentDialog(expense.id, expense.name, expense.maxGoal)
        }
        binding.rvExpenses.apply {
            this.adapter = adapter
            layoutManager = LinearLayoutManager(requireContext())
        }

        setupMonthSpinner(adapter)

        binding.btnAddExpense.setOnClickListener {
            val bundle = Bundle().apply {
                putInt("categoryId", categoryId)
                putString("categoryName", categoryName)
                putInt("userId", userId)
            }
            findNavController().navigate(R.id.action_CategoryDetailsFragment_to_ExpenseFragment, bundle)
        }
    }

    private fun setupMonthSpinner(adapter: ExpenseAdapter) {
        val months = arrayOf("All", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, months)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerMonth.adapter = spinnerAdapter

        binding.spinnerMonth.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    // Show all
                    viewModel.getExpensesForCategory(categoryId).observe(viewLifecycleOwner) { expenses ->
                        adapter.submitList(expenses)
                    }
                } else {
                    // Filter by month
                    val calendar = Calendar.getInstance()
                    calendar.set(Calendar.MONTH, position - 1)
                    calendar.set(Calendar.DAY_OF_MONTH, 1)
                    calendar.set(Calendar.HOUR_OF_DAY, 0)
                    calendar.set(Calendar.MINUTE, 0)
                    calendar.set(Calendar.SECOND, 0)
                    calendar.set(Calendar.MILLISECOND, 0)
                    val rangeStart = calendar.timeInMillis

                    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
                    calendar.set(Calendar.HOUR_OF_DAY, 23)
                    calendar.set(Calendar.MINUTE, 59)
                    calendar.set(Calendar.SECOND, 59)
                    calendar.set(Calendar.MILLISECOND, 999)
                    val rangeEnd = calendar.timeInMillis

                    viewModel.getExpensesForCategoryAndPeriod(categoryId, rangeStart, rangeEnd).observe(viewLifecycleOwner) { expenses ->
                        adapter.submitList(expenses)
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun showUpdateSpentDialog(expenseId: Int, expenseName: String, maxGoal: Double) {
        val builder = android.app.AlertDialog.Builder(requireContext())
        builder.setTitle("Update Spent for $expenseName")
        builder.setMessage("Enter the actual amount spent. Max Goal is R $maxGoal")
        
        val input = android.widget.EditText(requireContext())
        input.hint = "Amount Spent"
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        builder.setView(input)

        builder.setPositiveButton("Update") { dialog, _ ->
            val spent = input.text.toString().toDoubleOrNull()
            if (spent != null) {
                expenseViewModel.updateActualSpent(expenseId, spent)
                Toast.makeText(requireContext(), "Spent amount updated", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }
        builder.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}