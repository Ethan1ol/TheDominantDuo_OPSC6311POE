package com.example.opsc_ec.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.opsc_ec.database.AppDatabase
import com.example.opsc_ec.database.BudgetRepository
import com.example.opsc_ec.database.User
import com.example.opsc_ec.databinding.FragmentRegisterBinding
import com.example.opsc_ec.viewmodel.UserViewModel
import com.example.opsc_ec.viewmodel.UserViewModelFactory

class RegisterFragment : Fragment() {

    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!

    private val viewModel: UserViewModel by viewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val repository = BudgetRepository(database.appDao())
        UserViewModelFactory(repository)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnSubmit.setOnClickListener {
            val nameText = binding.editName.text.toString().trim()
            val surnameText = binding.editSurname.text.toString().trim()
            val usernameText = binding.editUsername.text.toString().trim()
            val emailText = binding.editEmail.text.toString().trim()
            val passwordText = binding.editPassword.text.toString().trim()
            val phoneText = binding.editPhoneNumber.text.toString().trim()

            var valid = true

            if (nameText.isEmpty()) {
                binding.editName.error = "Name required"
                valid = false
            }
            if (usernameText.length < 4) {
                binding.editUsername.error = "Username too short"
                valid = false
            }
            if (!emailText.contains("@")) {
                binding.editEmail.error = "Invalid email"
                valid = false
            }
            if (passwordText.length < 5 || !passwordText.any { it.isUpperCase() } || !passwordText.any { it.isDigit() }) {
                binding.editPassword.error = "Weak password"
                valid = false
            }

            if (valid) {
                val user = User(
                    username = usernameText,
                    password = passwordText,
                    name = nameText,
                    surname = surnameText,
                    email = emailText,
                    phoneNumber = phoneText
                )
                viewModel.register(user)
            }
        }

        viewModel.registerResult.observe(viewLifecycleOwner) { success ->
            if (success) {
                Toast.makeText(requireContext(), "Registration Successful", Toast.LENGTH_SHORT).show()
                findNavController().popBackStack()
            } else {
                Toast.makeText(requireContext(), "Username already exists", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}